# theme-gray/resources

This folder contains static resources (typically an `"images"` folder as well).
